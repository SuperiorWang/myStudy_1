package cn.eoe.app.entity;

public class NewsMoreResponse {
	
	private NewsCategoryListEntity response;

	public NewsCategoryListEntity getResponse() {
		return response;
	}

	public void setResponse(NewsCategoryListEntity response) {
		this.response = response;
	}
	

}
