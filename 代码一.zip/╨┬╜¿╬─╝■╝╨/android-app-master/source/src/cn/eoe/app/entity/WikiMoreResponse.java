package cn.eoe.app.entity;

public class WikiMoreResponse {

	private WikiCategoryListEntity response;

	public WikiCategoryListEntity getResponse() {
		return response;
	}

	public void setResponse(WikiCategoryListEntity response) {
		this.response = response;
	}
	
	
}
