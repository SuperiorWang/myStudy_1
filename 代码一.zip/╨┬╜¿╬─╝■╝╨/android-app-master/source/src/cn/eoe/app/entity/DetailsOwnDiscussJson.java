package cn.eoe.app.entity;

public class DetailsOwnDiscussJson {
	private DetailsOwnDiscussResponse response;

	public DetailsOwnDiscussResponse getResponse() {
		return response;
	}

	public void setResponse(DetailsOwnDiscussResponse response) {
		this.response = response;
	}
	
	
}
