package cn.eoe.app.entity;

public class UserJson {
	private UserResponse response;

	public UserResponse getResponse() {
		return response;
	}

	public void setResponse(UserResponse response) {
		this.response = response;
	}

}
