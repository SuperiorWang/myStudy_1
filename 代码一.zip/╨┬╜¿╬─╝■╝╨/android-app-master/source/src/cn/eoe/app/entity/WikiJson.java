package cn.eoe.app.entity;

public class WikiJson {
	
	private WikiResponseEntity response;

	public WikiResponseEntity getResponse() {
		return response;
	}

	public void setResponse(WikiResponseEntity response) {
		this.response = response;
	}
	

}
