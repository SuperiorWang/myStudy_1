package cn.eoe.app.entity;

public class NewsJson {
	
	private NewsResponseEntity response;

	public NewsResponseEntity getResponse() {
		return response;
	}

	public void setResponse(NewsResponseEntity response) {
		this.response = response;
	}
	
	
}
