package cn.eoe.app.entity;

public class NewsSearchJson {
	
	private NewsCategoryListEntity response;

	public NewsCategoryListEntity getResponse() {
		return response;
	}

	public void setResponse(NewsCategoryListEntity response) {
		this.response = response;
	}
	

}
