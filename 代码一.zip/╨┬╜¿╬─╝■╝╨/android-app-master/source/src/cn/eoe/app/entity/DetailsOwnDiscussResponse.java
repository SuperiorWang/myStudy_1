package cn.eoe.app.entity;

public class DetailsOwnDiscussResponse {
	private int isErr;
	private DetailsDiscussItem item;
	public int getIsErr() {
		return isErr;
	}
	public void setIsErr(int isErr) {
		this.isErr = isErr;
	}
	public DetailsDiscussItem getItem() {
		return item;
	}
	public void setItem(DetailsDiscussItem item) {
		this.item = item;
	}
	
}
