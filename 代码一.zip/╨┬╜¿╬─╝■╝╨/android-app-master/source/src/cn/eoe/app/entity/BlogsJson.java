package cn.eoe.app.entity;

public class BlogsJson {
	private BlogsResponseEntity response;

	public BlogsResponseEntity getResponse() {
		return response;
	}

	public void setResponse(BlogsResponseEntity response) {
		this.response = response;
	}
	
	
}
