package cn.eoe.app.entity;

public class WikiSearchJson {
	
	private WikiCategoryListEntity response ;

	public WikiCategoryListEntity getResponse() {
		return response;
	}

	public void setResponse(WikiCategoryListEntity response) {
		this.response = response;
	}
	

}
