package cn.eoe.app.entity;
/**
 * 赞接口的封装(需同服务端 字段同步)
 * @author wangxin
 *
 */
public class UserLikeEntity {
	
	private String good;
	private String bad;
	public String getGood() {
		return good;
	}
	public void setGood(String good) {
		this.good = good;
	}
	public String getBad() {
		return bad;
	}
	public void setBad(String bad) {
		this.bad = bad;
	}
	

}
