package cn.eoe.app.entity;

public class DetailJson {
	
	private DetailResponseEntity response;

	public DetailResponseEntity getResponse() {
		return response;
	}

	public void setResponse(DetailResponseEntity response) {
		this.response = response;
	}
	
	

}
