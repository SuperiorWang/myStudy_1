package cn.eoe.app.entity;
/**
 * 收藏 接口的封装
 * @author wangxin
 *
 */
public class FavoriteEntity {
	
	private String good;
	private String bad;
	public String getGood() {
		return good;
	}
	public void setGood(String good) {
		this.good = good;
	}
	public String getBad() {
		return bad;
	}
	public void setBad(String bad) {
		this.bad = bad;
	}
	
	

}
