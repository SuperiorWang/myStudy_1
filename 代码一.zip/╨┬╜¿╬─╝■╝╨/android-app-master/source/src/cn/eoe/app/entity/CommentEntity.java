package cn.eoe.app.entity;
/**
 * 评论部分的json的封装
 * @author wangxin
 *
 */
public class CommentEntity {
	
	private String get;
	private String submit;
	public String getGet() {
		return get;
	}
	public void setGet(String get) {
		this.get = get;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	
	

}
