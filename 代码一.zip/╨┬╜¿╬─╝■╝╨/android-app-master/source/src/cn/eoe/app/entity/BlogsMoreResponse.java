package cn.eoe.app.entity;

public class BlogsMoreResponse {

	private BlogsCategoryListEntity response;

	public BlogsCategoryListEntity getResponse() {
		return response;
	}

	public void setResponse(BlogsCategoryListEntity response) {
		this.response = response;
	}
	
	
}
