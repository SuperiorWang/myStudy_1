package cn.eoe.app.entity;

public class DetailsDiscussJson {
	private DetailsDiscussResponse response;

	public DetailsDiscussResponse getResponse() {
		return response;
	}

	public void setResponse(DetailsDiscussResponse response) {
		this.response = response;
	}
}
