package chp07;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class preparedStatemetTest {

	public static void main(String[] args) {
		
		if (args.length != 7){
			System.out.println("Paramete Error!Please Input Again!");
			System.exit(-1);
		}
		
		String name = args[0];
		int age = 0;
		try{
			age = Integer.parseInt(args[1]);
		}catch(NumberFormatException e){
			System.out.println("Paramete Error!Age should be Number Format!");
			System.exit(-1);
		}
		
		String sex = args[2];
		String address = args[3];
		String depart = args[4];
		
		int worklen = 0;
		try{
			worklen = Integer.parseInt(args[5]);
		}catch(NumberFormatException e){
			System.out.println("Parameter Error!Worklen should be Number Format!");
			System.exit(-1);
		}
		
		int wage = 0;
		try{
			wage = Integer.parseInt(args[6]);
		}catch(NumberFormatException e){
			System.out.println("Paramter Error!Wage should be Number Format!");
			System.exit(-1);
		}
		
		PreparedStatement pstmt = null;
		Connection conn = null;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = (Connection) DriverManager.getConnection("INSERT INTO staff(name,age,sex,address,depart,worklen,wage) VALUES(?,?,?,?,?,?,?)");
			
			pstmt.setString(1, name);
			pstmt.setInt(2, age);
			pstmt.setString(3, sex);
			pstmt.setString(4,address);
			pstmt.setString(5, depart);
			pstmt.setInt(6, worklen);
			pstmt.setInt(7,wage);
			pstmt.executeUpdate();
			
			System.out.print("�ɹ�����һ�����ݼ�¼!");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try{
				if (pstmt != null){
					pstmt.close();
					pstmt = null;
				}
				if (conn != null){
					conn.close();
					conn = null;
				}
			}catch (SQLException e){
				e.printStackTrace();
			}
		}
	}
}
